﻿// Copyright (c) Microsoft Corporation. All rights reserved. See License.txt in the project root for license information.
using System;

namespace MetadatatokenCollisionAssembly
{
    public class InterceptedType : MarshalByRefObject
    {
        public void Method1() { }
        public void Method2() { }
        public void Method3() { }
        public void Method4() { }
        public void Method5() { }
        public void Method6() { }
        public void Method7() { }
        public void Method8() { }
        public void MethodX() { }
    }
}
