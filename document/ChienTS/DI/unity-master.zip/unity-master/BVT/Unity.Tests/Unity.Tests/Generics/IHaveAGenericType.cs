// Copyright (c) Microsoft Corporation. All rights reserved. See License.txt in the project root for license information.
namespace Unity.Tests.Generics
{
    public interface IHaveAGenericType<T1>
    {
        T1 PropT1 { get; set; }

        void Set(T1 value);
    }
}