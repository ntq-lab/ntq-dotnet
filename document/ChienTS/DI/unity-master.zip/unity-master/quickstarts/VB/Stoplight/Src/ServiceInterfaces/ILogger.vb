﻿' Copyright (c) Microsoft Corporation. All rights reserved. See License.txt in the project root for license information.

Namespace StopLight.ServiceInterfaces
	Public Interface ILogger
		Sub Write(ByVal message As String)
	End Interface
End Namespace

