﻿MICROSOFT ENTERPRISE LIBRARY
UNITY APPLICATION BLOCK 3.0


Summary: This package contains QuickStarts to showcase the use of the Microsoft Unity Application Block

The most up-to-date version of the release notes and known issues is available online:
http://go.microsoft.com/fwlink/p/?LinkID=290919


Microsoft patterns & practices
http://microsoft.com/practices
