﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace _2.ContinueWith
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Func<object, int> func = Foo3;
            var task = new Task<int>(func, 200);
            Console.WriteLine(@"Task Start");
            // function continue phải có parameter là Task type của Task gọi (Task<int> task)
            task.ContinueWith(Foo);
            task.Start();
            Console.WriteLine(@"Task Done");
        }


        private static void FooException()
        {
            throw new Exception();
        }
        private static void Foo(Task task)
        {
            Console.WriteLine(@"Foo Start");
            Thread.Sleep(5000);
            Console.WriteLine(@"Foo Done");
        }
        private static void Foo(Task<int> task)
        {
            Console.WriteLine(@"Foo Start");
            Thread.Sleep(5000);
            Console.WriteLine(@"Foo Done");
        }
        static void Foo(int input)
        {
            Console.WriteLine(@"Foo Start");
            Thread.Sleep(5000);
            Console.WriteLine(@"Input {0}", input);
            Console.WriteLine(@"Foo Done");
        }

        static void Foo2(object input)
        {
            Console.WriteLine(@"Foo 2 Start");
            Thread.Sleep(5000);
            Console.WriteLine(@"Input {0}", input);
            Console.WriteLine(@"Foo 2 Done");
        }

        private static int Foo3(object input)
        {
            Console.WriteLine(@"Foo 3 Start");
            Thread.Sleep(5000);
            Console.WriteLine(@"Input {0}", input);
            Console.WriteLine(@"Foo 3 Done");
            return (int) input;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Func<object, int> func = Foo3;
            var task = new Task(FooException);
            Console.WriteLine(@"Task Start");
            // function continue phải có parameter là Task type của Task gọi (Task<int> task)
            task.ContinueWith(Foo, TaskContinuationOptions.NotOnFaulted);
            task.Start();
            Console.WriteLine(@"Task Done");
        }
    }
}
