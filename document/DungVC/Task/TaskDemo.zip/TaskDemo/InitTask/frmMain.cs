﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace InitTask
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Console.WriteLine(@"Task Start");
            Task.Factory.StartNew<int>(Foo);
            Console.WriteLine(@"Task Done");
        }


        private void button2_Click(object sender, EventArgs e)
        {
            var task = new Task<int>(Foo);
            Console.WriteLine(@"Task Start");
            task.Start();
            var result = task.Result;
            Console.WriteLine(@"Task Done");
            Console.WriteLine(@"Result: {0}", result);
        }
        private static int Foo()
        {
            Console.WriteLine(@"Foo Start");
            Thread.Sleep(5000);
            Console.WriteLine(@"Foo Done");
            return 100;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Action without parameter
            Task.Factory.StartNew(() => Foo(100));

            //// Action with parameter
            //Task.Factory.StartNew(Foo2, 100);

            //// Func with parameter and return result
            //Task.Factory.StartNew<int>(Foo3, 200);
            //Func<object, int> func = Foo3;
            //Task.Factory.StartNew(func, 200);
        }

        static void Foo(int input)
        {
            Console.WriteLine(@"Foo Start");
            Thread.Sleep(5000);
            Console.WriteLine(@"Input {0}", input);
            Console.WriteLine(@"Foo Done");
        }

        static void Foo2(object input)
        {
            Console.WriteLine(@"Foo Start");
            Thread.Sleep(5000);
            Console.WriteLine(@"Input {0}", input);
            Console.WriteLine(@"Foo Done");
        }

        static int Foo3(object input)
        {
            Console.WriteLine(@"Foo Start");
            Thread.Sleep(5000);
            Console.WriteLine(@"Input {0}", input);
            Console.WriteLine(@"Foo Done");
            return (int) input;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // with result
            //Func<object, int> func = Foo3;
            //var task = new Task<int>(func, 200);
            //Console.WriteLine(@"Task Start");
            //task.Start();
            //var result = task.Result;
            //Console.WriteLine(@"Task Done");
            //Console.WriteLine(@"Result: {0}", result);

            //// void result
            //var task2 = new Task(Foo2, 200);
            //Console.WriteLine(@"Task Start");
            //task2.Start();
            //task2.Wait();
            ////var t = Task.WhenAll(task2);
            //Console.WriteLine(@"Task Done");
        }
    }
}
