﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _4.ParallelTask
{
    public partial class Form1 : Form
    {

        List<int> lst = new List<int>();
        public Form1()
        {
            InitializeComponent();

            for (int i = 0; i < 100; i++)
            {
                lst.Add(i);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Console.Clear();
            Parallel.For(0, lst.Count, Foo);
        }

        private void Foo(int index)
        {
            Console.Clear();
            Console.WriteLine(lst[index]);
            Thread.Sleep(500);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Console.Clear();
            Parallel.ForEach(lst, Foo);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Start");
            Parallel.For(0, lst.Count, Foo2);
            Console.WriteLine("End");
        }


        private void Foo2(int index, ParallelLoopState state)
        {
            Thread.Sleep(500);
            if (index > 50)
            {
                /*
                 Break may be used to communicate to the loop that no other iterations after the current iteration need be run.
                 For example, if Break is called from the 100th iteration of a for loop iterating in parallel from 0 to 1000,
                 all iterations less than 100 should still be run, but the iterations from 101 through to 1000 are not necessary.*/
                state.Break();
                Console.WriteLine("Break task {0}", index);
            }
            Console.WriteLine(lst[index]);
        }

        private void Foo3(int index, ParallelLoopState state)
        {
            Thread.Sleep(500);
            if (index > 50)
            {
                /* Stop all iterations.*/
                state.Stop();
                Console.WriteLine("Stop task {0}", index);
            }
            Console.WriteLine(lst[index]);
        }

        private void button4_Click(object sender, EventArgs e)
        {

            Console.WriteLine("Start");
            Parallel.For(0, lst.Count, Foo3);
        }
    }
}
